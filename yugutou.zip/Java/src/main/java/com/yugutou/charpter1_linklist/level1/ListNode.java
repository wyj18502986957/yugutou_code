package com.yugutou.charpter1_linklist.level1;

/**
 * 在算法中最常用的链表定义方式
 */
public class ListNode {
    public int val;
    public ListNode next;

    public ListNode(int x) {
        val = x;
        next = null;
    }

    public static void main(String[] args) {
        ListNode listnode=new ListNode(1);
    }
}
