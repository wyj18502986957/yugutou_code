 #include <stdlib.h>
#include <stdio.h>
 struct ListNode {
      int val; //代表数据
      struct ListNode *next; //代表指针

      
 };
 